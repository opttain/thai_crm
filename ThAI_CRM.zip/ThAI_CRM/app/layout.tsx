import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ThAI CRM · Conexões que evoluem",
  description: "Seu atendimento, suas relações e suas próximas conquistas. Tudo em um só lugar.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="dark">
      <body className="antialiased">{children}</body>
    </html>
  );
}
