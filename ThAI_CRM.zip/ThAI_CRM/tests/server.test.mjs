import assert from 'node:assert/strict';
import { test, before } from 'node:test';
import { DatabaseSync } from 'node:sqlite';
import { build } from 'esbuild';
import { readFileSync, readdirSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

// This harness executes the actual domain handlers and generated migrations.
// Only platform identity and the D1 transport are adapted to an isolated SQLite database.
const sqlite = new DatabaseSync(':memory:');
sqlite.exec('PRAGMA foreign_keys=ON');
for(const file of readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort())sqlite.exec(readFileSync('drizzle/'+file,'utf8'));
class Statement {
 constructor(sql,args=[]){this.sql=sql;this.args=args;}
 bind(...args){return new Statement(this.sql,args);}
 execute(){const q=sqlite.prepare(this.sql);if(/^\s*SELECT/i.test(this.sql)||/RETURNING/i.test(this.sql)){const results=q.all(...this.args);return{results,success:true,meta:{changes:0}};}const r=q.run(...this.args);return{results:[],success:true,meta:{changes:Number(r.changes),last_row_id:Number(r.lastInsertRowid)}};}
 async run(){return this.execute();}
 async all(){return this.execute();}
 async first(column){const row=this.execute().results[0]||null;return column&&row?row[column]:row;}
}
globalThis.__testDB={prepare:(sql)=>new Statement(sql),batch:async stmts=>{sqlite.exec('BEGIN');try{const results=stmts.map(s=>s.execute());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
globalThis.__testIdentity={id:'alice',email:'alice@example.test',name:'Alice'};
mkdirSync('.test-artifacts',{recursive:true});
await build({entryPoints:['lib/server.ts','lib/integrations.ts'],outdir:'.test-artifacts',bundle:true,platform:'node',format:'esm',target:'node22',packages:'external',plugins:[{name:'platform-test-adapters',setup(b){b.onResolve({filter:/^cloudflare:workers$/},()=>({path:'env',namespace:'test'}));b.onResolve({filter:/^next\/headers$/},()=>({path:'headers',namespace:'test'}));b.onResolve({filter:/^next\/navigation$/},()=>({path:'navigation',namespace:'test'}));b.onLoad({filter:/.*/,namespace:'test'},args=>({contents:args.path==='env'?'export const env={DB:globalThis.__testDB};':args.path==='headers'?'export async function headers(){const u=globalThis.__testIdentity;return new Headers(u?{"oai-authenticated-user-id":u.id,"oai-authenticated-user-email":u.email,"oai-authenticated-user-full-name":encodeURIComponent(u.name),"oai-authenticated-user-full-name-encoding":"percent-encoded-utf-8"}:{});}':'export function redirect(url){throw new Error("Redirect: "+url);}'}));}}]});
const server=await import(pathToFileURL(resolve('.test-artifacts/server.js')));
const integration=await import(pathToFileURL(resolve('.test-artifacts/integrations.js')));
const {context,snapshot,all,rec,one,run,putRecord,conversation,conversationAction,sendMessage,cancelMessage,operation,processJobs}=server;
let alice,bob,attendant;
before(async()=>{alice=await context();globalThis.__testIdentity={id:'bob',email:'bob@example.test',name:'Bob'};bob=await context();await run("INSERT INTO members (id,account_id,user_id,email,name,role,active,team,created) VALUES ('agent',?,'agent-user','agent@example.test','Atendente','Atendente',1,?,?)",alice.accountId,alice.accountId+'_sales',Date.now());attendant={accountId:alice.accountId,me:{id:'agent',role:'Atendente',name:'Atendente',email:'agent@example.test',team:alice.accountId+'_sales',active:1}};});

test('authenticated accounts receive isolated, idempotently seeded workspaces',async()=>{
 const a=await snapshot(alice),b=await snapshot(bob);assert.equal(a.records.filter(x=>x.kind==='contact').length,8);assert.equal(a.conversations.length,8);assert.equal(b.conversations.length,8);assert.notEqual(a.account.id,b.account.id);assert(!a.records.some(x=>b.records.some(y=>y.id===x.id)));globalThis.__testIdentity={id:'alice',email:'alice@example.test',name:'Alice'};assert.equal((await context()).accountId,alice.accountId);assert.equal((await all(alice,'contact')).length,8);
});
test('anonymous, foreign-tenant and attendant accesses are rejected',async()=>{
 globalThis.__testIdentity=null;await assert.rejects(()=>context(),e=>e.status===401);await assert.rejects(()=>rec(bob,alice.accountId+'_mariana'),e=>e.status===404);await assert.rejects(()=>conversation(attendant,alice.accountId+'_conv-mariana'),e=>e.status===403);await assert.rejects(()=>putRecord(attendant,'channel',{name:'forbidden'}),e=>e.status===403);const a=await snapshot(attendant);assert(!a.conversations.some(x=>x.assignee===alice.me.id));assert(!a.records.some(x=>x.id===alice.accountId+'_mariana'));
});
test('claiming a conversation is atomic between two eligible users',async()=>{
 const id=alice.accountId+'_conv-lucas';const results=await Promise.allSettled([conversationAction(alice,id,'claim',{}),conversationAction(attendant,id,'claim',{})]);assert.equal(results.filter(x=>x.status==='fulfilled').length,1);assert.equal(results.filter(x=>x.status==='rejected').length,1);const c=await one('SELECT assignee FROM conversations WHERE id=?',id);assert([alice.me.id,attendant.me.id].includes(c.assignee));
});
test('contact validation, database uniqueness and optimistic concurrency preserve data',async()=>{
 await assert.rejects(()=>putRecord(alice,'contact',{name:'No identifier'}));const c=await putRecord(alice,'contact',{name:'Original',phone:'5511988877766'});await assert.rejects(()=>putRecord(alice,'contact',{name:'Duplicate',phone:'55 (11) 98887-7766'}));await putRecord(alice,'contact',{name:'Updated'},c.id,c.version);await assert.rejects(()=>putRecord(alice,'contact',{name:'Stale'},c.id,c.version),e=>e.status===409);assert.equal((await rec(alice,c.id)).name,'Updated');await assert.rejects(()=>putRecord(bob,'contact',{name:'Attack'},c.id));
 const results=await Promise.allSettled([putRecord(alice,'contact',{name:'Race A',phone:'5511977711100'}),putRecord(alice,'contact',{name:'Race B',phone:'5511977711100'})]);assert.equal(results.filter(x=>x.status==='fulfilled').length,1);
});
test('a cancelled send stays cancelled and idempotent requests create one message',async()=>{
 const id=alice.accountId+'_conv-mariana',mid=crypto.randomUUID();await sendMessage(alice,id,{id:mid,text:'Cancel this'});await sendMessage(alice,id,{id:mid,text:'Cancel this'});assert.equal((await server.rows('SELECT * FROM messages WHERE id=?',mid)).length,1);await cancelMessage(alice,mid);await run('UPDATE jobs SET due=0 WHERE id=?',mid);await processJobs(alice);assert.equal((await one('SELECT status FROM messages WHERE id=?',mid)).status,'cancelled');await assert.rejects(()=>cancelMessage(alice,mid),e=>e.status===409);
});
test('demo sends are explicitly simulated; internal notes do not change external activity',async()=>{
 const id=alice.accountId+'_conv-mariana',v=await conversation(alice,id);await sendMessage(alice,id,{direction:'note',text:'Private team note'});assert.equal((await conversation(alice,id)).last_external,v.last_external);const mid=crypto.randomUUID();await sendMessage(alice,id,{id:mid,text:'Demonstration message'});await run('UPDATE jobs SET due=0 WHERE id=?',mid);await processJobs(alice);const m=await one('SELECT * FROM messages WHERE id=?',mid);assert.equal(m.status,'simulated');assert.equal(m.external_id,null);assert.equal((await conversation(alice,id)).last_message,'Demonstration message');
});
test('blocking and closing prevent outbound messages; reopening retains event history',async()=>{
 const contact=await rec(alice,alice.accountId+'_mariana');await putRecord(alice,'contact',{blocked:true},contact.id);await assert.rejects(()=>sendMessage(alice,alice.accountId+'_conv-mariana',{text:'blocked'}),e=>e.status===409);await putRecord(alice,'contact',{blocked:false},contact.id);await conversationAction(alice,alice.accountId+'_conv-mariana','close',{result:'Objetivo atingido'});await assert.rejects(()=>sendMessage(alice,alice.accountId+'_conv-mariana',{text:'closed'}),e=>e.status===409);await conversationAction(alice,alice.accountId+'_conv-mariana','reopen',{});const events=await server.rows('SELECT type FROM events WHERE account_id=? AND target=?',alice.accountId,alice.accountId+'_conv-mariana');assert(events.some(x=>x.type==='conversation.close'));assert(events.some(x=>x.type==='conversation.reopen'));
});
test('campaign concurrent starts enqueue each recipient only once',async()=>{
 const cp=await rec(alice,alice.accountId+'_campaign1');const results=await Promise.allSettled([operation(alice,{action:'campaign',id:cp.id,operation:'start'}),operation(alice,{action:'campaign',id:cp.id,operation:'start'})]);assert.equal(results.filter(x=>x.status==='fulfilled').length,1);const jobs=await server.rows("SELECT * FROM jobs WHERE account_id=? AND target=? AND kind='campaign'",alice.accountId,cp.id);const contacts=(await all(alice,'contact')).filter(c=>c.tags?.includes('Novo lead')&&!c.blocked&&!c.archived);assert.equal(jobs.length,contacts.length);await operation(alice,{action:'campaign',id:cp.id,operation:'cancel'});assert.equal((await server.rows("SELECT * FROM jobs WHERE account_id=? AND target=? AND status='queued'",alice.accountId,cp.id)).length,0);
});
test('bot publication validates termination and automation resumes after a customer answer',async()=>{
 let bot=await putRecord(alice,'bot',{name:'Test bot',nodes:[{id:'a',type:'start'}]});await assert.rejects(()=>operation(alice,{action:'publishBot',id:bot.id}));bot=await putRecord(alice,'bot',{nodes:[{id:'a',type:'start'},{id:'b',type:'question',text:'What do you need?'},{id:'c',type:'condition',text:'support',yes:'d',no:'e'},{id:'d',type:'message',text:'Support selected'},{id:'e',type:'assign',team:alice.accountId+'_support'}]},bot.id);await operation(alice,{action:'publishBot',id:bot.id});bot=await rec(alice,bot.id);await integration.beginBot(alice,bot,alice.accountId+'_conv-mariana');assert.equal((await one('SELECT status FROM bot_runs WHERE conversation_id=?',alice.accountId+'_conv-mariana')).status,'waiting');await integration.advanceBot(alice,alice.accountId+'_conv-mariana','support');const v=await conversation(alice,alice.accountId+'_conv-mariana');assert.equal(v.team,alice.accountId+'_support');assert.equal(v.assignee,null);assert.equal((await one('SELECT status FROM bot_runs WHERE conversation_id=?',v.id)).status,'finished');
});
test('API tokens enforce scopes and revocation without exposing credentials in snapshots',async()=>{
 const {token}=await operation(alice,{action:'token',name:'Test reader',scopes:['contacts:read']});const req=new Request('https://example.test/api/v1/contacts',{headers:{Authorization:'Bearer '+token}});const c=await integration.bearerContext(req,'contacts:read');assert.equal(c.accountId,alice.accountId);await assert.rejects(()=>integration.bearerContext(req,'messages:write'),e=>e.status===403);assert(!JSON.stringify(await snapshot(alice)).includes(token));const record=(await all(alice,'token')).find(x=>x.name==='Test reader');await operation(alice,{action:'revokeToken',id:record.id});await assert.rejects(()=>integration.bearerContext(req,'contacts:read'),e=>e.status===401);
});
test('owner cannot be deactivated and overlapping office hours are rejected',async()=>{
 await assert.rejects(()=>operation(alice,{action:'member',id:alice.me.id,data:{name:'Alice',email:'alice@example.test',role:'Administrador',active:false}}),e=>e.status===409);await assert.rejects(()=>operation(alice,{action:'hours',data:{days:[1],start:'09:00',end:'18:00',schedule:{1:[{start:'09:00',end:'13:00'},{start:'12:00',end:'18:00'}]}}}),e=>e.status===400);
});
