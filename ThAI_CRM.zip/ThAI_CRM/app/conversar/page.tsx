import CaptureForm from "@/components/capture-form";
export const dynamic="force-dynamic";
export default function Page(){return <CaptureForm/>;}
