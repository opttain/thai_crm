# ThAI CRM

Aplicativo web de atendimento e relacionamento, com identidade iOS, tema #161616 e acentos #D400FF / #00D1FF. Interface em português do Brasil. Publicação privada com autenticação do ChatGPT.

## O que está implementado

- Caixa de entrada com fila, responsáveis, transferência, conclusão, reabertura, respostas rápidas, notas internas, anexos e tempo de cancelamento.
- Contatos com busca, etiquetas, bloqueio, arquivo, CSV com mapeamento e deduplicação, exportação dos resultados filtrados.
- Painéis e oportunidades com etapas, movimentação por arrastar ou formulário, valor, prazo, prioridade, comentários e histórico.
- Campanhas com audiência por etiqueta, agendamento, pausa, cancelamento, confirmação antes de iniciar e processamento por destinatário.
- Chatbots por regras com editor de blocos, condições, perguntas, opções, espera, transferência, validação, publicação e simulador do rascunho.
- Sequências com cópia das etapas por inscrição, intervalos, modelos, bots, etiquetas e tarefas. Interrupção ao receber resposta ou bloquear o contato.
- Indicadores por período/equipe, resultados, produtividade, relatório exportável e encerramento de protocolos selecionados.
- Gestão de usuários, perfis, equipes, empresa, horários semanais, múltiplos intervalos, exceções e canais.
- Tokens com escopos e revogação, webhooks assinados, botão de captura para sites, conectores WhatsApp Cloud API e Asaas.

## Armazenamento e identidade

O servidor usa D1 (binding lógico DB) e R2 (BUCKET). Migrações em `drizzle/`, schema declarativo em `db/schema.ts`. Nenhuma tabela é criada por requisições do produto. O primeiro acesso autenticado cria uma conta com exemplos fictícios em uma transação idempotente. Registros de demonstração são identificados pelo campo demo. O seletor no aviso de demonstração filtra a visualização.

A identidade vem dos cabeçalhos autenticados fornecidos pela plataforma. O servidor resolve a associação da identidade à conta e verifica permissões em cada ação. Não há senha própria do aplicativo. Um e-mail adicionado em Usuários recebe acesso à conta após entrar com a própria identidade, desde que também tenha acesso ao site privado. O sistema não envia convites por e-mail.

IDs de conta e permissões nunca são aceitos do navegador como prova de autorização. Tokens de API são armazenados por hash. Segredos de conectores permanecem na tabela de servidor `secrets` e não são incluídos nas respostas de consulta. Os anexos só são servidos após validação do acesso.

## Integrações e limites explícitos

A demonstração não envia mensagens a números reais. Conectar um canal exige credenciais válidas. O conector WhatsApp usa a versão da Graph API informada pelo administrador, valida o identificador do número e implementa envio de texto, mídia e modelos de corpo textual, sincronização de modelos, recebimento assinado e atualização de estado. Modelos que exigem componentes especiais, como cabeçalhos ou botões dinâmicos, precisam de extensão do conector. Instagram e outros provedores têm cadastro de canal, mas a conexão nativa não está implementada.

Callbacks e captação pública dependem de um endereço acessível externamente. A publicação inicial é privada; ela pode impedir que Meta, formulários externos ou agendadores cheguem às rotas. Alterar o público do site exige uma solicitação do proprietário, fora da configuração de credenciais do aplicativo.

A fila é persistente. Enquanto o aplicativo está visível, o cliente solicita processamento a cada sete segundos. Para execução contínua, configure um agendador autorizado para chamar POST `/api/v1/jobs/run` com o escopo `jobs:run`. Não há promessa de execução automática com o aplicativo fechado sem esse agendador. Retentativas de webhooks mantêm o identificador do evento. Envios interrompidos não são repetidos cegamente: exigem conferência para evitar duplicidade.

A API usa `Authorization: Bearer TOKEN`. Endpoints disponíveis: GET/POST `/api/v1/contacts`, GET `/api/v1/conversations`, POST `/api/v1/messages`, POST `/api/v1/jobs/run`. O POST de contato aceita `id` para atualização. A API de mensagens recebe um UUID de idempotência, ID do atendimento e texto. O processamento ocorre somente depois da validação de canal, bloqueio, estado e permissões.

O Asaas valida a chave no ambiente escolhido, cria cobrança simples com um ID de cliente já existente e consulta o estado do pagamento. Cobranças cuja confirmação foi interrompida são sinalizadas para conferência no provedor. Não há movimentação financeira na demonstração nem sincronização contínua de pagamentos sem processamento externo.

Os indicadores são calculados a partir do CRM. O consumo não equivale ao faturamento dos provedores. A visualização de eventos e jobs retorna até 500 registros recentes. Conversas, mensagens e cadastros são carregados por conta; para grandes operações, expandir a paginação e agregação no servidor. Importações são limitadas a 1.000 linhas por arquivo. Anexos têm limite de 15 MB.

## Validação e desenvolvimento

Dependências já estão descritas no package-lock. Build pelo script do ambiente Sites. Verificação de tipos: `npx tsc --noEmit`. Testes significativos: `node --test tests/server.test.mjs`.

Os testes executam os handlers reais e as migrações em SQLite isolado; somente o transporte D1 e os cabeçalhos de autenticação recebem adaptadores. Cobrem isolamento de contas, rejeição de acesso, concorrência na atribuição, validação/deduplicação, concorrência otimista, cancelamento/idempotência, estados simulados, notas, bloqueio, conclusão/reabertura, concorrência de campanhas, retomada de bots, escopos/revogação e proteção do administrador. Os conectores externos não foram exercitados com credenciais reais.

O gerador Drizzle desta versão escapou incorretamente expressões JSON nos dois índices de deduplicação. A migração 0001 foi revisada para usar `json_extract(data, '$.phone')` e `json_extract(data, '$.email')` como expressões SQLite válidas. Sempre revisar e executar novas migrações nos testes antes de publicar.

## Referências dos conectores

- WhatsApp: [Webhooks](https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/overview) e [assinatura de eventos](https://developers.facebook.com/docs/graph-api/webhooks/getting-started/).
- Asaas: [criação de cobrança](https://docs.asaas.com/reference/create-new-payment), [consulta de clientes](https://docs.asaas.com/reference/list-customers) e [Sandbox](https://docs.asaas.com/docs/sandbox-2).
