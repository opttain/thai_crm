import { requireChatGPTUser } from "../chatgpt-auth";
import CRM from "@/components/crm";
export const dynamic = "force-dynamic";
export default async function Page({ params }: { params: Promise<{path?: string[]}> }) {
  const { path = [] } = await params;
  const route = "/" + path.join("/");
  return <Authenticated route={route}/>;
}
async function Authenticated({ route }: { route: string }) {
  const user = await requireChatGPTUser(route);
  return <CRM initialRoute={route} identity={{name:user.fullName || user.email.split("@")[0],email:user.email}}/>;
}
