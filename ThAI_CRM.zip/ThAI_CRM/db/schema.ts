import { sqliteTable, text, integer, index, uniqueIndex } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";
export const accounts = sqliteTable("accounts", {
  id: text("id").primaryKey(), name: text("name").notNull(), owner: text("owner").notNull(),
  settings: text("settings").notNull().default("{}"), created: integer("created").notNull(),
});
export const members = sqliteTable("members", {
  id: text("id").primaryKey(), accountId: text("account_id").notNull().references(()=>accounts.id),
  userId: text("user_id"), email: text("email").notNull(), name: text("name").notNull(),
  role: text("role").notNull(), active: integer("active").notNull().default(1), team: text("team").notNull().default(""), created: integer("created").notNull(),
}, t => [uniqueIndex("member_user").on(t.userId), uniqueIndex("member_email").on(t.email), index("members_account").on(t.accountId)]);
export const records = sqliteTable("records", {
  id: text("id").primaryKey(), accountId: text("account_id").notNull().references(()=>accounts.id),
  kind: text("kind").notNull(), data: text("data").notNull(), demo: integer("demo").notNull().default(0),
  created: integer("created").notNull(), updated: integer("updated").notNull(), version: integer("version").notNull().default(1),
}, t => [index("records_account_kind").on(t.accountId,t.kind), uniqueIndex("contact_phone_unique").on(t.accountId,sql`json_extract(${t.data}, '$.phone')`).where(sql`${t.kind} = 'contact' AND coalesce(json_extract(${t.data}, '$.phone'), '') <> ''`), uniqueIndex("contact_email_unique").on(t.accountId,sql`json_extract(${t.data}, '$.email')`).where(sql`${t.kind} = 'contact' AND coalesce(json_extract(${t.data}, '$.email'), '') <> ''`)]);
export const conversations = sqliteTable("conversations", {
  id: text("id").primaryKey(), accountId: text("account_id").notNull().references(()=>accounts.id), contactId: text("contact_id").notNull(),
  protocol: text("protocol").notNull(), assignee: text("assignee"), team: text("team").notNull(), channel: text("channel").notNull(),
  status: text("status").notNull().default("open"), unread: integer("unread").notNull().default(0),
  lastMessage: text("last_message").notNull().default(""), created: integer("created").notNull(), updated: integer("updated").notNull(),
  closed: integer("closed"), firstReply: integer("first_reply"), lastExternal: integer("last_external"), result: text("result"),
  demo: integer("demo").notNull().default(0),
},t=>[index("conversations_account").on(t.accountId,t.updated),uniqueIndex("one_open_conversation").on(t.accountId,t.contactId,t.channel).where(sql`${t.status} = 'open'`)]);
export const messages = sqliteTable("messages", {
  id: text("id").primaryKey(), accountId: text("account_id").notNull(), conversationId: text("conversation_id").notNull(),
  text: text("text").notNull(), direction: text("direction").notNull(), status: text("status").notNull(),
  author: text("author").notNull(), attachment: text("attachment"), externalId: text("external_id"), created: integer("created").notNull(), meta:text("meta").notNull().default("{}"),
},t=>[index("messages_conversation").on(t.accountId,t.conversationId,t.created),uniqueIndex("messages_external").on(t.externalId)]);
export const events = sqliteTable("events", {
  id: text("id").primaryKey(), accountId: text("account_id").notNull(), target: text("target").notNull(),
  type: text("type").notNull(), text: text("text").notNull(), author: text("author").notNull(), created: integer("created").notNull(),
},t=>[index("events_account_target").on(t.accountId,t.target)]);
export const secrets = sqliteTable("secrets", {
  id: text("id").primaryKey(), accountId: text("account_id").notNull(), kind: text("kind").notNull(), value: text("value").notNull(),
},t=>[uniqueIndex("secret_account_kind").on(t.accountId,t.kind)]);
export const jobs = sqliteTable("jobs", {
  id: text("id").primaryKey(), accountId: text("account_id").notNull(), kind: text("kind").notNull(),
  target: text("target").notNull(), payload: text("payload").notNull(), status: text("status").notNull().default("queued"),
  due: integer("due").notNull(), attempts: integer("attempts").notNull().default(0), error: text("error"), updated: integer("updated").notNull(),
},t=>[index("jobs_due").on(t.accountId,t.status,t.due)]);
export const botRuns = sqliteTable("bot_runs", {
  conversationId:text("conversation_id").primaryKey(),accountId:text("account_id").notNull(),bot:text("bot").notNull(),nodes:text("nodes").notNull(),cursor:integer("cursor").notNull(),status:text("status").notNull(),updated:integer("updated").notNull(),
});
export const limits = sqliteTable("rate_limits", {id:text("id").primaryKey(),count:integer("count").notNull(),expires:integer("expires").notNull()});
