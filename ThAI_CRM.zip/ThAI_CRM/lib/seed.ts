export function makeSeed(owner:string,now:number){
 const records:any[]=[]; const add=(kind:string,id:string,data:any)=>records.push({kind,id,data});
 const contacts=[
  ["mariana","Mariana Costa","5511998764321","mariana@exemplo.com","Studio Costa","MC","#B06BF1",["Em negociação","Prioridade"]],
  ["lucas","Lucas Almeida","5511987654321","lucas@exemplo.com","Almeida & Co.","LA","#5CA8D9",["Novo lead"]],
  ["beatriz","Beatriz Santos","5521998761234","beatriz@exemplo.com","Florê Design","BS","#DD8F7F",["Cliente"]],
  ["rafael","Rafael Oliveira","5531998769876","rafael@exemplo.com","Nexo Digital","RO","#63B5A6",["Proposta enviada"]],
  ["camila","Camila Rodrigues","5541998765678","camila@exemplo.com","Camila Arquitetura","CR","#C49759",["Novo lead"]],
  ["pedro","Pedro Martins","5548998767654","pedro@exemplo.com","Forma Estúdio","PM","#8194E5",["Cliente"]],
  ["julia","Júlia Ferreira","5511999991234","julia@exemplo.com","Júlia Fotografia","JF","#BF74B8",["Em negociação"]],
  ["andre","André Lima","5521999995678","andre@exemplo.com","Horizonte Tech","AL","#65A8AF",["Novo lead"]],
 ];
 for(const [id,name,phone,email,company,avatar,color,tags] of contacts)add("contact",id as string,{name,phone,email,company,avatar,color,tags,notes:id==="mariana"?"Busca organizar o atendimento do estúdio e acompanhar novas oportunidades. Prefere conversar pela manhã.":"",instagram:"",archived:false,blocked:false});
 add("team","sales",{name:"Comercial",description:"Relacionamentos que se tornam oportunidades.",distribution:"manual",members:[owner],default:true});
 add("team","support",{name:"Suporte",description:"Cuidado em cada conversa.",distribution:"manual",members:[owner]});
 add("channel","whatsapp-demo",{name:"WhatsApp · demonstração",type:"WhatsApp",phone:"+55 (11) 4000-0000",status:"demo",team:"sales",bot:"",demo:true});
 add("board","sales-board",{name:"Funil de vendas",description:"Da primeira conversa à próxima conquista.",stages:["Novo lead","Qualificação","Proposta enviada","Negociação","Conquistado"],members:[owner],type:"Vendas",archived:false});
 const cards=[
  ["deal1","Gestão para Studio Costa","mariana",3,4800,"alta"],
  ["deal2","Expansão Almeida & Co.","lucas",0,7200,"média"],
  ["deal3","Novo projeto · Nexo Digital","rafael",2,3600,"média"],
  ["deal4","Atendimento integrado","camila",0,2400,"média"],
  ["deal5","Plano anual · Forma","pedro",4,9600,"alta"],
  ["deal6","Jornada de clientes","julia",1,3200,"baixa"]
 ];
 for(const [id,name,contact,index,value,priority] of cards)add("card",id as string,{name,contact,board:"sales-board",stage:["Novo lead","Qualificação","Proposta enviada","Negociação","Conquistado"][index as number],value,priority,owner,deadline:new Date(now+86400000*3).toISOString().slice(0,10),description:"Oportunidade de demonstração para explorar seu CRM.",comments:[]});
 add("template","welcome",{name:"Boas-vindas",content:"Olá, {{nome}}! Que bom ter você por aqui. Sou da equipe ThAI e vou te ajudar. Me conta um pouco sobre o que você precisa?",type:"Resposta rápida",channel:"WhatsApp",status:"local",archived:false});
 add("template","followup",{name:"Acompanhamento de proposta",content:"Oi, {{nome}}! Conseguiu avaliar nossa proposta para {{empresa}}? Estou por aqui para tirar suas dúvidas.",type:"Resposta rápida",channel:"WhatsApp",status:"local",archived:false});
 add("template","thanks",{name:"Agradecimento",content:"Foi um prazer conversar com você, {{nome}}! Quando precisar, é só chamar. Até a próxima!",type:"Resposta rápida",channel:"Todos",status:"local",archived:false});
 add("campaign","campaign1",{name:"Novas conexões · setembro",description:"Uma primeira conversa pode mudar tudo.",status:"draft",template:"welcome",channel:"whatsapp-demo",audience:"Novo lead",scheduled:"",archived:false});
 add("bot","bot1",{name:"Boas-vindas inteligente",description:"Receba, entenda e encaminhe cada contato.",category:"inbound",channel:"whatsapp-demo",team:"sales",status:"draft",nodes:[{id:"n1",type:"start",text:"Nova conversa"},{id:"n2",type:"message",text:"Olá! Bem-vindo à ThAI. Como podemos ajudar você hoje?"},{id:"n3",type:"choices",text:"Sobre o que vamos conversar?",options:["Conhecer a solução","Preciso de suporte"]},{id:"n4",type:"assign",text:"Transferir para a equipe",team:"sales"}]});
 add("sequence","seq1",{name:"Depois da proposta",description:"Mantenha o relacionamento no tempo certo.",status:"draft",stopOnReply:true,steps:[{id:"s1",type:"wait",minutes:1440},{id:"s2",type:"template",template:"followup"},{id:"s3",type:"task",text:"Retomar contato com o cliente"}]});
 for(const [id,name,enabled] of [["delay","Tempo de segurança",true],["classification","Classificação de atendimento",true],["crm","CRM",true],["asaas","Asaas",false]])add("app",id as string,{name,enabled,seconds:5});
 const previews=["Perfeito! Podemos agendar uma demonstração?","Olá! Gostaria de conhecer os planos 😊","Muito obrigada pela ajuda!","Consegui dar uma olhada na proposta.","Vocês atendem escritórios de arquitetura?","Tudo certo por aqui. Obrigado!","Oi! Tenho mais uma dúvida sobre o projeto.","Olá, vim pelo site de vocês."];
 const conv=contacts.map((c,i)=>({id:"conv-"+c[0],contactId:c[0],assignee:i===1||i===4||i===7?null:owner,team:i===2?"support":"sales",channel:"whatsapp-demo",unread:i===0?2:i===1||i===4?1:0,status:i===5?"closed":"open",lastMessage:previews[i],created:now-86400000*(i+1),updated:now-60000*(i===0?3:i*17+3),closed:i===5?now-3600000:null,firstReply:i===1||i===4||i===7?null:now-86400000*(i+1)+180000,lastExternal:now-60000*(i===0?3:i*17+3),result:i===5?"Objetivo atingido":null}));
 const messages:any[]=[];
 for(let i=0;i<conv.length;i++){
  const v=conv[i];
  if(i===0){
   const items=[["in","Oi! Estou procurando uma forma de organizar os atendimentos do meu estúdio."],["out","Oi, Mariana! Que bom te receber por aqui 😊\nMe conta: hoje, quantas pessoas fazem o atendimento com você?"],["in","Somos 4 pessoas. Acabamos nos perdendo nas conversas e nas propostas que enviamos."],["out","Entendi! Com a ThAI vocês acompanham cada conversa em um só lugar e organizam as propostas em um funil. Tudo conectado."],["note","Mariana tem interesse no plano para equipes. Enviar demonstração personalizada para o estúdio."],["in",previews[0]]];
   items.forEach(([direction,text],j)=>messages.push({id:"msg-mariana-"+j,conversationId:v.id,text,direction,status:direction==="out"?"simulated":direction==="note"?"note":"received",author:direction==="in"?"Mariana Costa":"Você",created:now-60000*(52-j*9)}));
  }else messages.push({id:"msg-"+i,conversationId:v.id,text:previews[i],direction:"in",status:"received",author:contacts[i][1],created:v.updated});
 }
 return {records,conversations:conv,messages};
}
