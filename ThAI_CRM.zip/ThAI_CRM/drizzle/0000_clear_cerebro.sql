CREATE TABLE `accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`owner` text NOT NULL,
	`settings` text DEFAULT '{}' NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `conversations` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`contact_id` text NOT NULL,
	`protocol` text NOT NULL,
	`assignee` text,
	`team` text NOT NULL,
	`channel` text NOT NULL,
	`status` text DEFAULT 'open' NOT NULL,
	`unread` integer DEFAULT 0 NOT NULL,
	`last_message` text DEFAULT '' NOT NULL,
	`created` integer NOT NULL,
	`updated` integer NOT NULL,
	`closed` integer,
	`first_reply` integer,
	`last_external` integer,
	`result` text,
	`demo` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`account_id`) REFERENCES `accounts`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `conversations_account` ON `conversations` (`account_id`,`updated`);--> statement-breakpoint
CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`target` text NOT NULL,
	`type` text NOT NULL,
	`text` text NOT NULL,
	`author` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `events_account_target` ON `events` (`account_id`,`target`);--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`kind` text NOT NULL,
	`target` text NOT NULL,
	`payload` text NOT NULL,
	`status` text DEFAULT 'queued' NOT NULL,
	`due` integer NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`error` text,
	`updated` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `jobs_due` ON `jobs` (`account_id`,`status`,`due`);--> statement-breakpoint
CREATE TABLE `members` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`user_id` text,
	`email` text NOT NULL,
	`name` text NOT NULL,
	`role` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`team` text DEFAULT '' NOT NULL,
	`created` integer NOT NULL,
	FOREIGN KEY (`account_id`) REFERENCES `accounts`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `member_user` ON `members` (`user_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `member_email` ON `members` (`email`);--> statement-breakpoint
CREATE INDEX `members_account` ON `members` (`account_id`);--> statement-breakpoint
CREATE TABLE `messages` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`conversation_id` text NOT NULL,
	`text` text NOT NULL,
	`direction` text NOT NULL,
	`status` text NOT NULL,
	`author` text NOT NULL,
	`attachment` text,
	`external_id` text,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `messages_conversation` ON `messages` (`account_id`,`conversation_id`,`created`);--> statement-breakpoint
CREATE UNIQUE INDEX `messages_external` ON `messages` (`external_id`);--> statement-breakpoint
CREATE TABLE `records` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`kind` text NOT NULL,
	`data` text NOT NULL,
	`demo` integer DEFAULT 0 NOT NULL,
	`created` integer NOT NULL,
	`updated` integer NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	FOREIGN KEY (`account_id`) REFERENCES `accounts`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `records_account_kind` ON `records` (`account_id`,`kind`);--> statement-breakpoint
CREATE TABLE `secrets` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`kind` text NOT NULL,
	`value` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `secret_account_kind` ON `secrets` (`account_id`,`kind`);