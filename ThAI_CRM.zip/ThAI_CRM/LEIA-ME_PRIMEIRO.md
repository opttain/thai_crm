# ThAI CRM — comece por aqui

Este pacote contém o código-fonte editável do ThAI CRM, com interface em português, visual inspirado no iOS, fundo #161616 e cores #D400FF e #00D1FF.

Aplicação publicada: https://thai-crm.flavioagmattos.chatgpt.site

## Conteúdo

- Atendimento: conversas, responsáveis, transferências, notas internas e anexos.
- CRM: contatos, importação e exportação CSV, painéis e oportunidades.
- Automação: campanhas, chatbots por regras, sequências e filas persistentes.
- Gestão: indicadores, relatórios, usuários, equipes, horários e configurações.
- Integrações: WhatsApp Cloud API, Asaas, tokens, webhooks e captura de contatos.
- Código do servidor, migrações SQL, testes e dependências com versões registradas.

O arquivo README.md detalha funcionalidades e limites de cada integração. Os chatbots são baseados em regras; esta versão não inclui um serviço de IA generativa conectado.

## Requisitos

- Node.js 22.13.0 ou superior compatível com as dependências do package-lock.json.
- npm e acesso à internet para baixar as dependências.
- Ambiente capaz de executar o runtime local do Cloudflare Workers.

A aplicação usa React, TypeScript, Vinext/Vite, Tailwind CSS, Cloudflare Workers, banco D1 e armazenamento R2. É um projeto web com servidor e banco de dados, e não um arquivo HTML que funciona abrindo diretamente no navegador.

## Preparar o desenvolvimento local

Extraia o ZIP e abra um terminal dentro da pasta ThAI_CRM. Instale as dependências preservando as versões do projeto:

```sh
npm run install:ci
```

Gere a aplicação e a configuração local do Worker:

```sh
npm run build
```

Prepare um banco D1 local novo, aplicando as migrações em ordem:

```sh
npx wrangler d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_clear_cerebro.sql
npx wrangler d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_colossal_roxanne_simpson.sql
```

Esses comandos executam diretamente os arquivos SQL. Use-os uma vez na criação do banco; para um banco já inicializado, aplique apenas as migrações ainda pendentes. O estado local do D1 e do R2 fica em .wrangler/state. O ID de banco zerado da configuração original é um identificador de desenvolvimento, não uma conexão com o banco publicado.

Inicie o servidor de desenvolvimento:

```sh
npm run dev
```

Acesse http://localhost:5173 e use a opção de entrar. No desenvolvimento local, o plugin incluído fornece uma identidade fictícia de teste. Esse acesso é limitado a localhost e ao modo de desenvolvimento; ele não faz login real na conta do ChatGPT.

O primeiro acesso cria uma conta local com registros fictícios de demonstração. O pacote não contém uma cópia do banco de produção. As dependências, os arquivos compilados e o estado de execução serão criados pelos comandos acima.

## Autenticação e publicação

Na publicação existente, a identidade autenticada é fornecida pela plataforma Sites. O código não implementa login próprio com e-mail e senha.

O arquivo .openai/hosting.json preserva a vinculação ao projeto original. Para criar um projeto independente, registre o novo projeto no ambiente de hospedagem escolhido e ajuste sua configuração. Não reutilize a vinculação original para publicar uma cópia independente.

Para hospedar fora do ambiente original, configure os bindings DB (D1) e BUCKET (R2), aplique as migrações no banco de destino e integre um provedor de identidade confiável. A camada de entrada deve validar a identidade e impedir que cabeçalhos de autenticação enviados pelo visitante sejam aceitos como prova de acesso. O acesso fictício local não serve como autenticação de produção.

O comando npm run start executa o Worker compilado localmente, sem o acesso fictício fornecido pelo servidor de desenvolvimento. Para editar e testar a interface local, use npm run dev.

## Configurar as integrações

As credenciais devem ser inseridas no ambiente de destino. Nenhuma chave de WhatsApp, Asaas, token de API ou cópia dos dados de clientes acompanha a exportação.

- WhatsApp: configure as credenciais e a versão da Graph API no canal; configure também os callbacks e sua verificação no provedor.
- Asaas: selecione o ambiente e informe sua chave. O conector trabalha com IDs de clientes existentes no provedor.
- Webhooks, captação externa e API: as rotas precisam estar acessíveis aos sistemas autorizados. O site publicado é privado por padrão.
- Campanhas e sequências: a fila é processada enquanto o aplicativo está visível. Para execução contínua com o aplicativo fechado, configure um agendador autorizado que chame POST /api/v1/jobs/run com token de escopo jobs:run.

Instagram e outros canais possuem cadastro, mas não têm conector nativo implementado. Os indicadores de consumo são operacionais e não representam o faturamento dos provedores. Consulte README.md para os demais limites.

## Onde modificar

| Objetivo | Arquivos e pastas |
| --- | --- |
| Cores, tipografia e aparência global | app/globals.css, app/layout.tsx |
| Navegação e estrutura principal | components/crm.tsx, components/workspace.tsx |
| Caixa de atendimento | components/inbox.tsx |
| Contatos e painéis | components/crm-pages.tsx |
| Campanhas, chatbots e sequências | components/automation-pages.tsx |
| Indicadores e relatórios | components/reports.tsx |
| Configurações e integrações na interface | components/settings-pages.tsx |
| Regras de negócio e permissões | lib/server.ts, lib/domain.ts |
| Conectores externos | lib/integrations.ts |
| Dados fictícios iniciais | lib/seed.ts |
| Estrutura do banco e migrações | db/schema.ts, drizzle/ |
| Endpoints do servidor | app/api/ |
| Verificações automatizadas | tests/server.test.mjs |

## Verificações

Após instalar as dependências:

```sh
npx tsc --noEmit
node --test tests/server.test.mjs
npm run build
```

A versão exportada passou pela compilação, verificação de tipos e 11 testes de regras do servidor no ambiente de desenvolvimento original. Os testes incluem isolamento de contas, permissões, concorrência, deduplicação, cancelamento de envios e escopos de tokens. Conectores não foram testados com credenciais reais. A instalação em outro computador depende dos requisitos e configurações descritos acima.

O ZIP foi verificado quanto à integridade e à correspondência dos arquivos com a revisão registrada em EXPORTACAO.json. As licenças de componentes incorporados foram preservadas em build/ e vendor/.
