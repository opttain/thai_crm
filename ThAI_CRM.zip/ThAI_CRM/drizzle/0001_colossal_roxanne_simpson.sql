CREATE TABLE `bot_runs` (
	`conversation_id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`bot` text NOT NULL,
	`nodes` text NOT NULL,
	`cursor` integer NOT NULL,
	`status` text NOT NULL,
	`updated` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `rate_limits` (
	`id` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
ALTER TABLE `messages` ADD `meta` text DEFAULT '{}' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX `one_open_conversation` ON `conversations` (`account_id`,`contact_id`,`channel`) WHERE "conversations"."status" = 'open';--> statement-breakpoint
CREATE UNIQUE INDEX `contact_phone_unique` ON `records` (`account_id`, json_extract(`data`, '$.phone')) WHERE "records"."kind" = 'contact' AND coalesce(json_extract("records"."data", '$.phone'), '') <> '';--> statement-breakpoint
CREATE UNIQUE INDEX `contact_email_unique` ON `records` (`account_id`, json_extract(`data`, '$.email')) WHERE "records"."kind" = 'contact' AND coalesce(json_extract("records"."data", '$.email'), '') <> '';