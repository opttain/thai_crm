export const emailOK=(s:string)=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
export const normalizePhone=(s:string)=>s.replace(/\D/g,"");
export const supportedKinds=["contact","board","card","team","template","campaign","bot","sequence","channel","app","webhook","token","file","enrollment","charge"];
export function validateRecord(kind:string,d:Record<string,any>){
  if(!supportedKinds.includes(kind))throw new Error("Tipo de registro inválido.");
  if(!String(d.name||"").trim())throw new Error("Informe o nome.");
  if(kind==="contact"){
    if(!d.phone&&!d.email&&!d.instagram)throw new Error("Informe telefone, e-mail ou Instagram.");
    if(d.email&&!emailOK(d.email))throw new Error("Informe um e-mail válido.");
    if(d.phone&&(normalizePhone(d.phone).length<10||normalizePhone(d.phone).length>15))throw new Error("Informe o telefone com DDI e DDD.");
  }
  if(kind==="card"&&(!d.board||!d.stage))throw new Error("Selecione o painel e a etapa.");
  if(kind==="card"&&(Number(d.value)<0||!Number.isFinite(Number(d.value||0))))throw new Error("O valor deve ser maior ou igual a zero.");
  if(kind==="template"&&!d.content?.trim())throw new Error("Escreva o conteúdo da mensagem.");
  if(kind==="board"&&(!Array.isArray(d.stages)||d.stages.length<2||d.stages.some((x:string)=>!x.trim())||new Set(d.stages).size!==d.stages.length))throw new Error("Crie pelo menos duas etapas com nomes diferentes.");
}
export function allowedConversation(c:{assignee:string|null;team:string},me:{id:string;role:string;team:string}){return me.role!=="Atendente"||c.assignee===me.id||(!c.assignee&&(!me.team||c.team===me.team));}
export function validateBot(nodes:any[]){
  if(!nodes.length)throw new Error("Adicione ao menos um passo ao fluxo.");
  if(nodes[0].type!=="start")throw new Error("O fluxo deve começar com Início.");
  if(!nodes.some(n=>n.type==="end"||n.type==="assign"))throw new Error("Adicione um encerramento ou transferência para uma equipe.");
  for(const n of nodes){if(["message","question","condition","choices"].includes(n.type)&&!n.text?.trim())throw new Error("Preencha o conteúdo de todos os passos.");if(n.type==="assign"&&!n.team)throw new Error("Escolha a equipe de destino.");}
  const validTypes=["start","message","question","choices","condition","wait","assign","end"];
  if(new Set(nodes.map(n=>n.id)).size!==nodes.length)throw new Error("Cada bloco precisa de um identificador único.");
  for(const n of nodes){if(!validTypes.includes(n.type))throw new Error("Tipo de bloco inválido.");if(n.type==="choices"&&(!n.options?.length||n.options.some((x:string)=>!x.trim())))throw new Error("Preencha as opções do menu.");if(n.type==="wait"&&(!Number.isFinite(Number(n.minutes))||Number(n.minutes)<1))throw new Error("Defina um intervalo de espera válido.");}
  const visited=new Set<number>(),visiting=new Set<number>();
  const walk=(i:number)=>{if(i<0||i>=nodes.length)throw new Error("Todos os caminhos precisam terminar em encerramento ou transferência.");if(visiting.has(i))throw new Error("O fluxo contém um ciclo. Revise os destinos das condições.");if(visited.has(i))return;visiting.add(i);const n=nodes[i];if(!["end","assign"].includes(n.type)){const next=n.type==="condition"?[n.yes,n.no].map(v=>v?nodes.findIndex(x=>x.id===v):i+1):[i+1];next.forEach(walk);}visiting.delete(i);visited.add(i);};walk(0);
}
export function fillTemplate(t:string,contact:{name?:string;company?:string}){return t.replace(/\{\{nome\}\}/g,contact.name||"").replace(/\{\{empresa\}\}/g,contact.company||"");}
export function safeWebhookURL(s:string){
  const u=new URL(s); const h=u.hostname.toLowerCase();
  if(u.protocol!=="https:"||u.username||u.password||u.port&&u.port!=="443"||h==="localhost"||h.endsWith(".local")||h.endsWith(".internal")||/^\d+(\.\d+){3}$/.test(h)||h.includes(":"))throw new Error("Use um endereço HTTPS público, sem credenciais na URL.");
  return u.toString();
}
