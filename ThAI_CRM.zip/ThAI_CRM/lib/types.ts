export type Item = {id:string;kind:string;name?:string;demo?:boolean;created?:number;updated?:number;version?:number;[key:string]:any};
export type Conversation = {id:string;contact_id:string;protocol:string;assignee:string|null;team:string;channel:string;status:string;unread:number;last_message:string;created:number;updated:number;closed:number|null;first_reply:number|null;last_external:number|null;result:string|null;demo:number};
export type Message = {id:string;conversation_id:string;text:string;direction:string;status:string;author:string;created:number;attachment?:string|null};
export type Member = {id:string;name:string;email:string;role:string;active:number;user_id?:string|null;team:string};
export type Activity = {id:string;target:string;type:string;text:string;author:string;created:number};
export type Snapshot = {account:{id:string;name:string;owner:string;settings:any};me:Member;members:Member[];records:Item[];conversations:Conversation[];messages:Message[];events:Activity[];jobs:any[];usage:{files:number;bytes:number};serverTime:number};
export const routes = {
  inbox:"/atendimentos",contacts:"/crm/contatos",boards:"/crm/paineis",campaigns:"/apps/campanhas",bots:"/apps/chatbots",sequences:"/apps/sequencias",apps:"/apps/integrados",dashboard:"/relatorios/indicadores",reports:"/relatorios/atendimentos",infrastructure:"/relatorios/infraestrutura",users:"/ajustes/usuarios",teams:"/ajustes/equipes",templates:"/ajustes/modelos",account:"/ajustes/conta",hours:"/ajustes/horarios",channels:"/ajustes/canais",usage:"/ajustes/consumo",integrations:"/ajustes/integracoes"
} as const;
export type View = keyof typeof routes;
export const titles:Record<View,string>={inbox:"Atendimentos",contacts:"Contatos",boards:"Painéis",campaigns:"Campanhas",bots:"Chatbots",sequences:"Sequências",apps:"Aplicativos integrados",dashboard:"Indicadores",reports:"Relatório de atendimentos",infrastructure:"Consumo de infraestrutura",users:"Usuários",teams:"Equipes",templates:"Modelos de mensagens",account:"Sua conta",hours:"Horário de atendimento",channels:"Canais de atendimento",usage:"Consumo de conversas",integrations:"Integrações"};
export const money=(n:number)=>new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL",maximumFractionDigits:0}).format(n||0);
export const initials=(n:string)=>n.split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join("").toUpperCase();
export const date=(n:number)=>new Intl.DateTimeFormat("pt-BR",{day:"2-digit",month:"short"}).format(n);
export const time=(n:number)=>new Intl.DateTimeFormat("pt-BR",{hour:"2-digit",minute:"2-digit",timeZone:"America/Sao_Paulo"}).format(n);
export const statusLabel:Record<string,string>={open:"Em andamento",closed:"Concluído",draft:"Rascunho",scheduled:"Agendada",running:"Em execução",paused:"Pausada",completed:"Concluída",cancelled:"Cancelada",failed:"Falha",pending:"Configuração pendente",simulated:"Simulado",queued:"Na fila",sent:"Enviado ao provedor",active:"Ativo",inactive:"Inativo",published:"Publicado",archived:"Arquivado",delivered:"Entregue",read:"Lido",received:"Recebido",note:"Nota interna"};
